package com.fesva;

public class millis {
    long start = System.currentTimeMillis();
    // поиск смысла жизни ...
    long finish = System.currentTimeMillis();
    long timeConsumedMillis = finish - start;

    public static void main(String[] args) {

        String chars[] = new String[]{"А", "В"};

        for (int i = 0; i < chars.length; i++) {
            for (int j = 0; j < 10; j++) {
                String currChar = chars[i];
                String number = String.format("(%s%s)(%d%d%d)%s(%d%d)",
                        currChar, currChar, j, j, j, currChar, j, j);
                System.out.println(number);
            }
        }
    }
}
