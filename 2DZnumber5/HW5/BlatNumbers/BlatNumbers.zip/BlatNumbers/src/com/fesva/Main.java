package com.fesva;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
	// write your code here
        //Scanner in = new Scanner((System.in));
        ArrayList<String> mylist = new ArrayList<>();
        // Генерация номеров первоначальная
        String chars[] = new String[]{"А", "В", "C", "D", "E", "F",
            "G", "H", "I", "J", "K", "L", "M", "N",
            "А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "К", "Л", "М",
            "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч",
            "Ш", "Щ", "Э", "Ю", "Я"};

        for (int i = 0; i < chars.length; i++) {
            for (int j = 0; j < 10; j++) {
                for(int k = 0; k < 10; k++){
                    for (int l = 0; l < 10; l++) {
                        String currChar = chars[i];
                        String number = String.format("%s%s%d%d%d%s%d%d",
                                currChar, currChar, j, j, j, currChar, k, l);
                        //System.out.println(number);
                        mylist.add(number);
                    }
                }
            }
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        //Arrays.sort(mylist);
        String searchNum;
        //Scanner reader = new Scanner(System.in);
        System.out.println("Какой номер вы ищете?");
        while(true) {
            //searchNum = reader.nextInt();
            try {
                String command = reader.readLine().trim();
                if (command.equals("quit"))
                    break;

                long start = System.currentTimeMillis();
                // поиск смысла жизни ...
                //int tmp = (int) Arrays.binarySearch(mylist,command);
                //isNumInArr(numbers, searchNum);
                boolean tmp = mylist.contains(command);
                long finish = System.currentTimeMillis();
                long timeConsumedMillis = finish - start;
                System.out.println(tmp + " (" + timeConsumedMillis + " ms)");
                System.out.println("Попробуйте ввести другое ");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        /*
        Main.main1(" ");

        String inp = new String();
        do{
            System.out.println("Введите номер для проверки: ");
            inp = in.nextLine();
            NumberCar.main(inp);

        }while(inp != "exit");
        */

    }

    private static int [] generatAnyNumbers(int countNum) {
        int [] result = new int[countNum];
        for (int i = 0; i < countNum; i++) {
            result[i] = (int)(Math.random()*countNum);
        }

        return result;
    }

    private static void isNumInArr(int [] arr, int num) {
        long start = System.currentTimeMillis();
        // поиск смысла жизни ...
        int tmp = Arrays.binarySearch(arr,num);
        long finish = System.currentTimeMillis();
        long timeConsumedMillis = finish - start;

        if (tmp > 0)
            System.out.print(" True - Это число есть в списке!\n" + timeConsumedMillis );
        else
            System.out.print(" False - Число не найдено\n" + timeConsumedMillis );
    }

    public static void main1(String args)  {
        int [] numbers = generatAnyNumbers(10);
        Arrays.sort(numbers);
        int searchNum;
        Scanner reader = new Scanner(System.in);
        System.out.println("Какой номер вы ищете?");
        while(true) {
            searchNum = reader.nextInt();
            long start = System.currentTimeMillis();
            // поиск смысла жизни ...
            isNumInArr(numbers, searchNum);
            long finish = System.currentTimeMillis();
            long timeConsumedMillis = finish - start;
            System.out.println("(" + timeConsumedMillis + " ms)");
            System.out.println("Попробуйте ввести другое ");
        }
    }

}
